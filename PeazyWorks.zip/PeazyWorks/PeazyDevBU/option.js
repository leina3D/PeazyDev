class option{
constructor(user, curr_pos_lat ,curr_pos_lng , curr_day, curr_time, text_info, req_category, pnumber){
    this.user = user; // presents the name of the volunteer
    this.curr_pos_lat = curr_pos_lat  ; // presents the current postion of the volunteer
    this.curr_pos_lng = curr_pos_lng ;
    this.curr_day = curr_day; // presents the current time zone of the volunteer
    this.curr_time = curr_time;
    this.req_content = text_info;
    this.req_category = req_category;
    this.pnumber = pnumber;
  }
}
