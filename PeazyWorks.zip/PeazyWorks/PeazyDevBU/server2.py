import os
import http.server
import socketserver
import json
from http import HTTPStatus

FILE_FORMAT = [".png", ".ico", ".jpg", ".jpeg"]

def get_and_increase_counter():
    file1 = open("./counter.txt", "r+", encoding='utf8')
    counter_value = int(file1.read())
    file1.seek(0)
    file1.write(str(counter_value+1))
    file1.close()
    return counter_value


def delete_option(file_name):
    os.remove('./options/'+file_name+".json")


def save_json_in_options(opt_json):
    OPTIONS_PATH = r"C:\Users\Daniel\PycharmProjects\PeazyWorks\PeazyDevBU\options"
    obj = json.loads(opt_json)
    file_name = "option"+str(get_and_increase_counter())  # this one should be the opt name
    obj['file_name'] = file_name
    complete_name = os.path.join(OPTIONS_PATH, file_name + ".json")
    file1 = open(complete_name, "w", encoding='utf8')
    file1.write(json.dumps(obj))
    file1.close()

class Handler(http.server.SimpleHTTPRequestHandler):

    def do_GET(self):
        self.send_response(HTTPStatus.OK)
        ques_mark_loc = self.path.find("?")
        if ques_mark_loc >= 0:
            address =self.path[:ques_mark_loc]
            params = self.path[ques_mark_loc:]
        else:
            address = self.path

        if address == '/getOptions':
            self.send_header("Content-type", "text/json")
            result = '['
            for filename in os.listdir(os.getcwd()+"/options"):
                result += open(os.getcwd()+"/options/"+filename, "r").read()
                result += ','
            result = result[:-1]
            result += ']'
            self.end_headers()
            self.wfile.write(result.encode())
        else:
            request_type = address[address.find("."):]

            if request_type in FILE_FORMAT:
                if request_type == ".png":
                    self.send_header("Content-type", "image/png")
                if request_type == ".jpeg":
                    self.send_header("Content-type", "image/jpeg")
                if request_type == ".jpg":
                    self.send_header("Content-type", "image/jpg")
                if request_type == ".ico":
                    self.send_header("Content-type", "image/ico")
                if request_type == ".css":
                    self.send_header("Content-type", "text/css")
                self.end_headers()
                with open(os.getcwd() + address, "rb") as input_file:
                    self.wfile.write(input_file.read())
            else:
                self.end_headers()
                self.wfile.write(open(os.getcwd() + address, "r", encoding="utf8").read().encode("utf8"))

    def do_POST(self):
        if self.path == '/new_req':
            body = self.rfile.read(int(self.headers['Content-Length']))
            save_json_in_options(str(body.decode('utf-8')))
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b'')
        elif self.path == '/delete':
            body = self.rfile.read(int(self.headers['Content-Length']))
            delete_option(str(body.decode('utf-8')))
            self.send_response(301)
            self.send_header('Location', '/getOptions')
            self.end_headers()






httpd = socketserver.TCPServer(('', 8000), Handler)
httpd.serve_forever()
