var DISTANCE = 0;
var CURR_LAT = 0 ;
var CURR_LNG = 0;
getLocation();


function get_requests(){
  var xhttp = new XMLHttpRequest();
  xhttp.addEventListener("load", reqListener);
  xhttp.open("GET","getOptions",true);
  xhttp.send();
}


function delete_file(file_name){
  var xhttp = new XMLHttpRequest();
  xhttp.addEventListener("load", ()=>{location.reload()});
  xhttp.open("POST","delete",true);
  xhttp.setRequestHeader("Content-type", "text/plain");
  xhttp.send(file_name);
}


function reqListener () {
  var table = document.getElementById("table_req");

  console.log(this.responseText);
  if (this.responseText.length > 2 ){
    var array = JSON.parse(this.responseText);
    array.forEach((item, i) => {
      addRow(item,i+1);
    });
  }
}

function distance(lat1, lon1, lat2, lon2) {
 var p = 0.017453292519943295;    // Math.PI / 180
 var c = Math.cos;
 var a = 0.5 - c((lat2 - lat1) * p)/2 +
         c(lat1 * p) * c(lat2 * p) *
         (1 - c((lon2 - lon1) * p))/2;

 var distance_ = 12742 * Math.asin(Math.sqrt(a)); // 2 * R; R = 6371 km
 if (distance_ < 1){
   return distance_.toFixed(1)*100+" מטרים";
 }
 if(distance_ > 1){
 return distance_.toFixed(1)+" קילומטרים";
}
}


function getLocation() {
if (navigator.geolocation) {
  navigator.geolocation.getCurrentPosition(get_final_distance);
} else {

  alert("Geolocation is not supported by this browser.");
}
}

function get_final_distance(position){
  var curr_lat1 = position.coords.latitude;
  var curr_lng1 = position.coords.longitude;
  CURR_LAT = curr_lat1;
  CURR_LNG = curr_lng1;
}

function info_pop_up(info){
  alert(info);
}

function addRow(item, i) {

			var table = document.getElementById("table_req");

			var row = table.insertRow(i);

			var cell1 = row.insertCell(0);

      if (item["req_category"] == "btn_1"){
        cell1.innerHTML= "<img src=\"./val_pics/up_down_01.png\" width=\"90%\" height=\"100%\">"
      }
      if (item["req_category"] == "btn_2"){
        cell1.innerHTML= "<img src=\"./val_pics/assist_01.png\" width=\"100%\" height=\"100%\">"
      }
      if (item["req_category"] == "btn_3"){
        cell1.innerHTML= "<img src=\"./val_pics/blocked_01.png\" width=\"100%\" height=\"100%\">"
      }
      if (item["req_category"] == "btn_4"){
        cell1.innerHTML= "<img src=\"./val_pics/other_01.png\" width=\"100%\" height=\"100%\">"
      }
      if (item["req_category"] == "btn_5"){
        cell1.innerHTML= "<img src=\"./val_pics/trans_01.png\" width=\"100%\" height=\"100%\">"
      }
      if (item["req_category"] == "btn_6"){
        cell1.innerHTML= "<img src=\"./val_pics/cars_01.png\" width=\"100%\" height=\"100%\">"
      }

      var cell2 = row.insertCell(1);
      var marker_lat = item["curr_pos_lat"];
      var marker_lng = item["curr_pos_lng"];
      cell2.innerHTML = distance(marker_lat, marker_lng, CURR_LAT , CURR_LNG  );
			//cell2.innerHTML = "lat :"+item["curr_pos_lat"]+" lng: "+item["curr_pos_lng"];

      var cell3 = row.insertCell(2);
			cell3.innerHTML = item["curr_time"]+" "+item["curr_day"];

      var cell4 = row.insertCell(3);
      cell4.innerHTML = item["user"];


      var cell5 = row.insertCell(4);
      var button2 = document.createElement("button");
      button2.innerHTML = "i";
      button2.id = "info_btn";
      button2.src = "./img/info_icon.png"
      button2.onclick = ()=>{(alert(alert_info(item["user"], item["req_content"], item["pnumber"])))}
      //button.onclick = ()=>{delete_file(item["file_name"]);}
      cell5.appendChild(button2);


      var cell6 = row.insertCell(5);
      var button = document.createElement("button");
      button.innerHTML = "אשר/י";
      button.id = "delete_btn";
      button.onclick = ()=>{delete_file(item["file_name"]);}
      cell6.appendChild(button);
		}
    function alert_info(user_name, req_info, number){
      return("שם המשתמש: "+ user_name + "\n" +"אינפורמציה נוספת:"+ req_info+"\n"+"טלפון נייד:"+number)
    }
