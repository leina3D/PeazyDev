
var marker ;

function initMap() {
  getLocation();
  //alert(curr_lng);
  //alert(curr_lat);
}

function getLocation() {
 if (navigator.geolocation) {
   navigator.geolocation.getCurrentPosition(showPosition);
 } else {
   alert("Geolocation is not supported by this browser.");
 }
}

function showPosition(position) {
 curr_lat = position.coords.latitude;
 curr_lng = position.coords.longitude;
 var map = new google.maps.Map(document.getElementById('map'), {zoom: 20, center: {lat : curr_lat , lng : curr_lng}});
 map.addListener('click', function(e) {
   placeMarkerAndPanTo(e.latLng, map);
 });
}

function placeMarkerAndPanTo(latLng, map) {
  if (marker) {
    marker.setMap(null);
  }
  marker = new google.maps.Marker({
    position: latLng,
    map: map
  });
  map.panTo(latLng);
}

function pick_place(){
  if (marker){
    var lng = marker.getPosition().lng();
    var lat = marker.getPosition().lat();
    //var pnumber = document.getElementById("pnumber");
    //var name = document.getElementById("name");
    window.location.href = "help_req5.html?lng="+lng+"&lat="+lat;
  }
  else{
    alert("בחר מקום ולאחר מכן לחץ על כפתור זה, תודה");
  }
}
