// Initialize and add the map
function initMap() {
  // The location of Tel avivS
  var Givatayim = {lat : 32.07225, lng :34.81253};
  // The map, centered at Tel Aviv

  var map = new google.maps.Map(
      document.getElementById('map'), {zoom: 15, center: Givatayim});
    fetch("/getOptions")
    .then(result => {
        return result.json()
     })
     .then(result2 => {
	var options = [];
	result2.forEach(opt => {
	    options.push(new option(opt.name,opt.lng, opt.lat, opt.date, opt.phone) );
	});

	  options.forEach(option => {
		var marker = new google.maps.Marker({position: option.position, map: map});
		var infowindow = new google.maps.InfoWindow({
          content: "name : "+getDetails(option)[0]+"<br>"+" Phone number : "+getDetails(option)[3]+"<br>"+"Published in: "+getDetails(option)[2]

        });

        marker.addListener('click', function() {
          infowindow.open(map, marker);
        });
	  });
     });



}
