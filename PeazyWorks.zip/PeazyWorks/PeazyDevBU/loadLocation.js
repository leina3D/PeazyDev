function loadLocation(){
  var url_string = window.location.href;
  var url = new URL(url_string);
  var pin_lng = url.searchParams.get("lng");
  var pin_lat = url.searchParams.get("lat");

  document.getElementById("inLng").value = pin_lng;
  document.getElementById("inLat").value = pin_lat;

}
