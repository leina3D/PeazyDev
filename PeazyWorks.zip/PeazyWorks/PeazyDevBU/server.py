import os
import http.server
import socketserver
import json

from http import HTTPStatus


def save_json_in_options(opt_json):
    OPTIONS_PATH = r"C:\Users\Daniel\PycharmProjects\PeazyDevBU\options"
    obj = json.loads(opt_json)
    file_name = str(obj["user"])  # this one should be the opt name
    complete_name = os.path.join(OPTIONS_PATH, file_name + ".json")
    file1 = open(complete_name, "w", encoding='utf8')
    file1.write(str(opt_json))
    file1.close()

class Handler(http.server.SimpleHTTPRequestHandler):

    def do_GET(self):
        self.send_response(HTTPStatus.OK)
        self.end_headers()
        if self.path == '/getOptions':
            self.send_header("Content-type", "text/json")
            result = '['
            for filename in os.listdir(os.getcwd()+"/options"):
                result += open(os.getcwd()+"/options/"+filename, "r").read()
                result += ','
            result = result[:-1]
            result += ']'
            self.wfile.write(result.encode())
        else:
            self.send_header("Content-type", "image/PNG")
            self.wfile.write(open(os.getcwd() + self.path, "r", encoding="utf-8").read().encode("utf-8"))

    def do_POST(self):
        body = self.rfile.read(int(self.headers['Content-Length']))
        save_json_in_options(str(body.decode('utf-8')))
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b'')


httpd = socketserver.TCPServer(('', 8000), Handler)
httpd.serve_forever()
